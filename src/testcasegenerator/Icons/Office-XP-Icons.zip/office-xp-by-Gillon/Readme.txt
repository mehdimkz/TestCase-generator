Office icons by Gillon
http://gillon.deviantart.com/