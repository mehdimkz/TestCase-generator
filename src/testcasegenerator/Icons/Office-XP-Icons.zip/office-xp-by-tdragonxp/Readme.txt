Circular Office XP Icons by TDRAGONXP
http://wincustomize.com/info.aspx?acid=973414